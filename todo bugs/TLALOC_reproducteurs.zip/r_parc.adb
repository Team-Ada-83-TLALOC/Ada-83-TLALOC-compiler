with TEXT_IO; use TEXT_IO;
procedure R_PARC is
  type NOEUD;
  type LIEN is access NOEUD;
  type NOEUD is record
    V : INTEGER;
    G, D : LIEN;
  end record;
  R : LIEN := null;
  N : INTEGER := 0;
  S : INTEGER := 0;
  procedure INSERER( A : in out LIEN; K : INTEGER ) is
  begin
    if A = null then
      A := new NOEUD'( K, null, null ); N := N + 1;
    elsif K < A.V then INSERER( A.G, K );
    elsif K > A.V then INSERER( A.D, K );
    end if;
  end INSERER;
  procedure PARCOURIR( A : LIEN ) is
  begin
    if A /= null then
      PARCOURIR( A.G );
      S := S + A.V;
      PARCOURIR( A.D );
    end if;
  end PARCOURIR;
begin
  INSERER( R, 5 ); INSERER( R, 3 ); INSERER( R, 8 ); INSERER( R, 1 ); INSERER( R, 4 );
  PUT( "NOEUDS" ); PUT( CHARACTER'VAL( CHARACTER'POS( '0' ) + N ) );
  if R.G.D /= null then PUT( " G.D=" ); PUT( CHARACTER'VAL( CHARACTER'POS( '0' ) + R.G.D.V ) ); end if;
  PARCOURIR( R );
  PUT( " S=" ); PUT( CHARACTER'VAL( CHARACTER'POS( 'A' ) + S ) );
  NEW_LINE;
end R_PARC;
