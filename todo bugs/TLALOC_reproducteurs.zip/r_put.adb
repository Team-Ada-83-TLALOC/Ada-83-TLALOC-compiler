with TEXT_IO; use TEXT_IO;
procedure R_PUT is
  subtype MOT is STRING( 1 .. 8 );
  type MOTS is array( 1 .. 3 ) of MOT;
  M : MOTS := ( others => "ABCDEFGH" );
begin
  PUT( "<" ); PUT( M( 2 ) ); PUT( ">" ); NEW_LINE;
end R_PUT;
