with TEXT_IO; use TEXT_IO;
procedure R_NOMBRE is
  N : constant := 37;
  type T is array( 0 .. N - 1 ) of INTEGER;   -- AMBIGUOUS EXPRESSION TYPE (LRM 3.6.1 : INTEGER)
  X : T := ( others => 0 );
begin
  X( N - 1 ) := 5;
  if X( 36 ) = 5 then PUT_LINE( "OK" ); end if;
end R_NOMBRE;
