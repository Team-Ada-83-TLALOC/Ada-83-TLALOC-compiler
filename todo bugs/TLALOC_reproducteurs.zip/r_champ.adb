with TEXT_IO; use TEXT_IO;
procedure R_CHAMP is
  type ARTICLE is record
    VAR : INTEGER;              -- nom d'une macro de codi_HX : fasmg echoue
    CLE : INTEGER;              -- idem
  end record;
  A : ARTICLE := ( 1, 2 );
begin
  if A.VAR + A.CLE = 3 then PUT_LINE( "OK" ); end if;
end R_CHAMP;
